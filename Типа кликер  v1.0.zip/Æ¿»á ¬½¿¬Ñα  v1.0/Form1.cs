﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace Типа_кликер__v1._0
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            textBoxALG.Text = "";
            textBoxANG.Text = "";
        }
        int total = 0;
        int Oc(string s)
        {
            int sum = 0;
            string[] subs = s.Split(' ');
            foreach (var sub in subs)
            {

                string ocenka = sub;
                int koef = 1;

                if (sub.IndexOf("*") > 0)
                {
                    string[] number1 = sub.Split('*');
                    ocenka = number1[0];
                    koef = Convert.ToInt32(number1[1]);
                }

                if (ocenka == "5")
                {
                    sum += 20 * koef;
                }
                if (ocenka == "4")
                {
                    sum += 4 * koef;
                }
                if (ocenka == "2")
                {
                    sum -= 100 * koef;
                }
            }
            total += sum;
            return sum;
        }
        private void BONYSALG_Click(object sender, EventArgs e)
        {
            total = 0;
            BONYSALG.Text = "Бонус равен: " + Convert.ToString(Oc(textBoxALG.Text));
        }
        private void BONYSANG_Click_1(object sender, EventArgs e)
        {
            total = 0;
            BONYSANG.Text = "Бонус равен: " + Convert.ToString(Oc(textBoxANG.Text));
        }
        private void BONYSRODLIT_Click(object sender, EventArgs e)
        {
            total = 0;
            BONYSRODLIT.Text = "Бонус равен: " + Convert.ToString(Oc(textBoxRODLIT.Text));
        }
        private void BONYSGEOG_Click_1(object sender, EventArgs e)
        {
            total = 0;
            BONYSGEOG.Text = "Бонус равен: " + Convert.ToString(Oc(textBoxGEOG.Text));
        }
        private void BONYSGEOM_Click_1(object sender, EventArgs e)
        {
            total = 0;
            BONYSGEOM.Text = "Бонус равен: " + Convert.ToString(Oc(textBoxGEOM.Text));
        }






        private void checkALG_CheckedChanged(object sender, EventArgs e)
        {
            if (checkALG.Checked)
            {
                textBoxALG.Visible = true;
                ALGEBRATEXT.Visible = true;
                BONYSALG.Visible = true;
            }
            else
            {
                BONYSALG.Visible = false;
                textBoxALG.Visible = false;
                ALGEBRATEXT.Visible = false;
            }
        }
        private void checkANG_CheckedChanged(object sender, EventArgs e)
        {
            if (checkANG.Checked)
            {
                textBoxANG.Visible = true;
                labelANG.Visible = true;
                BONYSANG.Visible = true;
            }
            else
            {
                BONYSANG.Visible = false;
                textBoxANG.Visible = false;
                labelANG.Visible = false;
            }
        }

        private void checkRODLIT_CheckedChanged(object sender, EventArgs e)
        {
            if (checkRODLIT.Checked)
            {
                textBoxRODLIT.Visible = true;
                labelRODLIT.Visible = true;
                BONYSRODLIT.Visible = true;
            }
            else
            {
                BONYSRODLIT.Visible = false;
                textBoxRODLIT.Visible = false;
                labelRODLIT.Visible = false;
            }
        }

        private void checkGEOG_CheckedChanged(object sender, EventArgs e)
        {
            if (checkGEOG.Checked)
            {
                textBoxGEOG.Visible = true;
                labelGEOG.Visible = true;
                BONYSGEOG.Visible = true;
            }
            else
            {
                BONYSGEOG.Visible = false;
                textBoxGEOG.Visible = false;
                labelGEOG.Visible = false;
            }
        }

        private void checkGEOM_CheckedChanged(object sender, EventArgs e)
        {
            if (checkGEOM.Checked)
            {
                textBoxGEOM.Visible = true;
                labelGEOM.Visible = true;
                BONYSGEOM.Visible = true;
            }
            else
            {
                BONYSGEOM.Visible = false;
                textBoxGEOM.Visible = false;
                labelGEOM.Visible = false;
            }
        }

        private void checkINF_CheckedChanged(object sender, EventArgs e)
        {
            if (checkINF.Checked)
            {
                textBoxINF.Visible = true;
                labelINF.Visible = true;
                BONYSINF.Visible = true;
            }
            else
            {
                BONYSINF.Visible = false;
                textBoxINF.Visible = false;
                labelINF.Visible = false;
            }
        }

        private void checkHIS_CheckedChanged(object sender, EventArgs e)
        {
            if (checkHIS.Checked)
            {
                textBoxHIS.Visible = true;
                labelHIS.Visible = true;
                BONYSHIS.Visible = true;
            }
            else
            {
                BONYSHIS.Visible = false;
                textBoxHIS.Visible = false;
                labelHIS.Visible = false;
            }
        }

        private void checkLIT_CheckedChanged(object sender, EventArgs e)
        {
            if (checkLIT.Checked)
            {
                textBoxLIT.Visible = true;
                labelLIT.Visible = true;
                BONYSLIT.Visible = true;
            }
            else
            {
                BONYSLIT.Visible = false;
                textBoxLIT.Visible = false;
                labelLIT.Visible = false;
            }
        }

        private void checkMUS_CheckedChanged(object sender, EventArgs e)
        {
            if (checkMUS.Checked)
            {
                textBoxMUS.Visible = true;
                labelMUS.Visible = true;
                BONYSMUS.Visible = true;
            }
            else
            {
                BONYSMUS.Visible = false;
                textBoxMUS.Visible = false;
                labelMUS.Visible = false;
            }
        }

        private void checkOBJ_CheckedChanged(object sender, EventArgs e)
        {
            if (checkOBJ.Checked)
            {
                textBoxOBJ.Visible = true;
                labelOBJ.Visible = true;
                BONYSOBJ.Visible = true;
            }
            else
            {
                BONYSOBJ.Visible = false;
                textBoxOBJ.Visible = false;
                labelOBJ.Visible = false;
            }
        }

        private void checkRUS_CheckedChanged(object sender, EventArgs e)
        {
            if (checkRUS.Checked)
            {
                textBoxRUS.Visible = true;
                labelRUS.Visible = true;
                BONYSRUS.Visible = true;
            }
            else
            {
                BONYSRUS.Visible = false;
                textBoxRUS.Visible = false;
                labelRUS.Visible = false;
            }
        }

        private void checkBIO_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBIO.Checked)
            {
                textBoxBIO.Visible = true;
                labelBIO.Visible = true;
                BONYSBIO.Visible = true;
            }
            else
            {
                BONYSBIO.Visible = false;
                textBoxBIO.Visible = false;
                labelBIO.Visible = false;
            }
        }

        private void checkPHY_CheckedChanged(object sender, EventArgs e)
        {
            if (checkPHY.Checked)
            {
                textBoxPHY.Visible = true;
                labelPHY.Visible = true;
                BONYSPHY.Visible = true;
            }
            else
            {
                BONYSPHY.Visible = false;
                textBoxPHY.Visible = false;
                labelPHY.Visible = false;
            }
        }

        private void checkFIZRA_CheckedChanged(object sender, EventArgs e)
        {
            if (checkFIZRA.Checked)
            {
                textBoxFIZRA.Visible = true;
                labelFIZRA.Visible = true;
                BONYSFIZRA.Visible = true;
            }
            else
            {
                BONYSFIZRA.Visible = false;
                textBoxFIZRA.Visible = false;
                labelFIZRA.Visible = false;
            }
        }

        private void checkHIM_CheckedChanged(object sender, EventArgs e)
        {
            if (checkHIM.Checked)
            {
                textBoxHIM.Visible = true;
                labelHIM.Visible = true;
                BONYSHIM.Visible = true;
            }
            else
            {
                BONYSHIM.Visible = false;
                textBoxHIM.Visible = false;
                labelHIM.Visible = false;
            }
        }

        private void checkCHER_CheckedChanged(object sender, EventArgs e)
        {
            if (checkCHER.Checked)
            {
                textBoxCHER.Visible = true;
                labelCHER.Visible = true;
                BONYSCHER.Visible = true;
            }
            else
            {
                BONYSCHER.Visible = false;
                textBoxCHER.Visible = false;
                labelCHER.Visible = false;
            }
        }

        private void checkOBS_CheckedChanged(object sender, EventArgs e)
        {
            if (checkOBS.Checked)
            {
                textBoxOBS.Visible = true;
                labelOBS.Visible = true;
                BONYSOBS.Visible = true;
            }
            else
            {
                BONYSOBS.Visible = false;
                textBoxOBS.Visible = false;
                labelOBS.Visible = false;
            }
        }

        private void checkIZO_CheckedChanged(object sender, EventArgs e)
        {
            if (checkIZO.Checked)
            {
                textBoxIZO.Visible = true;
                labelIZO.Visible = true;
                BONYSIZO.Visible = true;
            }
            else
            {
                BONYSIZO.Visible = false;
                textBoxIZO.Visible = false;
                labelIZO.Visible = false;
            }
        }

        private void BONYSINF_Click(object sender, EventArgs e)
        {
            total = 0;
            BONYSINF.Text = "Бонус равен: " + Convert.ToString(Oc(textBoxINF.Text));
        }

        private void BONYSHIS_Click(object sender, EventArgs e)
        {
            total = 0;
            BONYSHIS.Text = "Бонус равен: " + Convert.ToString(Oc(textBoxHIS.Text));
        }

        private void BONYSLIT_Click(object sender, EventArgs e)
        {
            total = 0;
            BONYSLIT.Text = "Бонус равен: " + Convert.ToString(Oc(textBoxLIT.Text));
        }

        private void BONYSMUS_Click(object sender, EventArgs e)
        {
            total = 0;
            BONYSMUS.Text = "Бонус равен: " + Convert.ToString(Oc(textBoxMUS.Text));
        }

        private void BONYSOBJ_Click(object sender, EventArgs e)
        {
            total = 0;
            BONYSOBJ.Text = "Бонус равен: " + Convert.ToString(Oc(textBoxOBJ.Text));
        }

        private void checkBoxMATPRACT_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxMATPRACT.Checked)
            {
                textBoxMATPRACT.Visible = true;
                labelMATPRACT.Visible = true;
                BONYSMATPRACT.Visible = true;
            }
            else
            {
                BONYSMATPRACT.Visible = false;
                textBoxMATPRACT.Visible = false;
                labelMATPRACT.Visible = false;
            }
        }

        private void checkRODYAZ_CheckedChanged(object sender, EventArgs e)
        {
            if (checkRODYAZ.Checked)
            {
                textBoxRODYAZ.Visible = true;
                labelRODYAZ.Visible = true;
                BONYSRODYAZ.Visible = true;
            }
            else
            {
                BONYSRODYAZ.Visible = false;
                textBoxRODYAZ.Visible = false;
                labelRODYAZ.Visible = false;
            }
        }

        private void BONYSMATPRACT_Click(object sender, EventArgs e)
        {
            total = 0;
            BONYSMATPRACT.Text = "Бонус равен: " + Convert.ToString(Oc(textBoxMATPRACT.Text));
        }

        private void BONYSRUS_Click(object sender, EventArgs e)
        {
            total = 0;
            BONYSRUS.Text = "Бонус равен: " + Convert.ToString(Oc(textBoxRUS.Text));
        }

        private void BONYSBIO_Click(object sender, EventArgs e)
        {
            total = 0;
            BONYSBIO.Text = "Бонус равен: " + Convert.ToString(Oc(textBoxBIO.Text));
        }

        private void BONYSPHY_Click(object sender, EventArgs e)
        {
            total = 0;
            BONYSPHY.Text = "Бонус равен: " + Convert.ToString(Oc(textBoxPHY.Text));
        }

        private void BONYSFIZRA_Click(object sender, EventArgs e)
        {
            total = 0;
            BONYSFIZRA.Text = "Бонус равен: " + Convert.ToString(Oc(textBoxFIZRA.Text));
        }

        private void BONYSHIM_Click(object sender, EventArgs e)
        {
            total = 0;
            BONYSHIM.Text = "Бонус равен: " + Convert.ToString(Oc(textBoxHIM.Text));
        }

        private void BONYSCHER_Click(object sender, EventArgs e)
        {
            total = 0;
            BONYSCHER.Text = "Бонус равен: " + Convert.ToString(Oc(textBoxCHER.Text));
        }

        private void BONYSOBS_Click(object sender, EventArgs e)
        {
            total = 0;
            BONYSOBS.Text = "Бонус равен: " + Convert.ToString(Oc(textBoxOBS.Text));
        }

        private void BONYSRODYAZ_Click(object sender, EventArgs e)
        {
            total = 0;
            BONYSRODYAZ.Text = "Бонус равен: " + Convert.ToString(Oc(textBoxRODYAZ.Text));
        }

        private void BONYSIZO_Click(object sender, EventArgs e)
        {
            total = 0;
            BONYSIZO.Text = "Бонус равен: " + Convert.ToString(Oc(textBoxIZO.Text));
        }

        private void buttonBONYSMIRA_Click(object sender, EventArgs e)
        {
            buttonBONYSMIRA.Text = "Общий бонус " + textBoxNAMEBABY.Text + ":" + Convert.ToString(Convert.ToInt32(Oc(textBoxALG.Text)) + Convert.ToInt32(Oc(textBoxANG.Text)) + Convert.ToInt32(Oc(textBoxGEOG.Text)) + Convert.ToInt32(Oc(textBoxRODLIT.Text)) + Convert.ToInt32(Oc(textBoxGEOM.Text)) + Convert.ToInt32(Oc(textBoxINF.Text)) + Convert.ToInt32(Oc(textBoxHIS.Text)) + Convert.ToInt32(Oc(textBoxLIT.Text)) + Convert.ToInt32(Oc(textBoxMUS.Text)) + Convert.ToInt32(Oc(textBoxOBJ.Text)) + Convert.ToInt32(Oc(textBoxMATPRACT.Text)) + Convert.ToInt32(Oc(textBoxRUS.Text)) + Convert.ToInt32(Oc(textBoxBIO.Text)) + Convert.ToInt32(Oc(textBoxPHY.Text)) + Convert.ToInt32(Oc(textBoxFIZRA.Text)) + Convert.ToInt32(Oc(textBoxHIM.Text)) + Convert.ToInt32(Oc(textBoxCHER.Text)) + Convert.ToInt32(Oc(textBoxOBS.Text)) + Convert.ToInt32(Oc(textBoxRODYAZ.Text)) + Convert.ToInt32(Oc(textBoxIZO.Text)));
        }

        private void checkALL_CheckedChanged(object sender, EventArgs e)
        {
            if (checkALL.Checked)
            {
                checkALG.Checked = true;
                checkANG.Checked = true;
                checkRODLIT.Checked = true;
                checkGEOG.Checked = true;
                checkGEOM.Checked = true;
                checkINF.Checked = true;
                checkHIS.Checked = true;
                checkLIT.Checked = true;
                checkMUS.Checked = true;
                checkOBJ.Checked = true;
                checkBoxMATPRACT.Checked = true;
                checkRUS.Checked = true;
                checkBIO.Checked = true;
                checkPHY.Checked = true;
                checkFIZRA.Checked = true;
                checkHIM.Checked = true;
                checkCHER.Checked = true;
                checkOBS.Checked = true;
                checkRODYAZ.Checked = true;
                checkIZO.Checked = true;
            }
            else
            {
                checkALG.Checked = false;
                checkANG.Checked = false;
                checkRODLIT.Checked = false;
                checkGEOG.Checked = false;
                checkGEOM.Checked = false;
                checkINF.Checked = false;
                checkHIS.Checked = false;
                checkLIT.Checked = false;
                checkMUS.Checked = false;
                checkOBJ.Checked = false;
                checkBoxMATPRACT.Checked = false;
                checkRUS.Checked = false;
                checkBIO.Checked = false;
                checkPHY.Checked = false;
                checkFIZRA.Checked = false;
                checkHIM.Checked = false;
                checkCHER.Checked = false;
                checkOBS.Checked = false;
                checkRODYAZ.Checked = false;
                checkIZO.Checked = false;
            }
        }
    }
}