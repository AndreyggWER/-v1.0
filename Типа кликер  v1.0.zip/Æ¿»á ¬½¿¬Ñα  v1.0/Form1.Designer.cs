﻿namespace Типа_кликер__v1._0
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonBONYSMIRA = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkRODYAZ = new System.Windows.Forms.CheckBox();
            this.checkBoxMATPRACT = new System.Windows.Forms.CheckBox();
            this.checkIZO = new System.Windows.Forms.CheckBox();
            this.checkMUS = new System.Windows.Forms.CheckBox();
            this.checkCHER = new System.Windows.Forms.CheckBox();
            this.checkHIM = new System.Windows.Forms.CheckBox();
            this.checkFIZRA = new System.Windows.Forms.CheckBox();
            this.checkPHY = new System.Windows.Forms.CheckBox();
            this.checkBIO = new System.Windows.Forms.CheckBox();
            this.checkRODLIT = new System.Windows.Forms.CheckBox();
            this.checkOBJ = new System.Windows.Forms.CheckBox();
            this.checkOBS = new System.Windows.Forms.CheckBox();
            this.checkLIT = new System.Windows.Forms.CheckBox();
            this.checkHIS = new System.Windows.Forms.CheckBox();
            this.checkINF = new System.Windows.Forms.CheckBox();
            this.checkGEOM = new System.Windows.Forms.CheckBox();
            this.checkGEOG = new System.Windows.Forms.CheckBox();
            this.checkRUS = new System.Windows.Forms.CheckBox();
            this.checkANG = new System.Windows.Forms.CheckBox();
            this.checkALG = new System.Windows.Forms.CheckBox();
            this.textBoxNAMEBABY = new System.Windows.Forms.TextBox();
            this.labelNAMEBABY = new System.Windows.Forms.Label();
            this.ALGEBRATEXT = new System.Windows.Forms.Label();
            this.textBoxALG = new System.Windows.Forms.TextBox();
            this.BONYSALG = new System.Windows.Forms.Button();
            this.BONYSANG = new System.Windows.Forms.Button();
            this.textBoxANG = new System.Windows.Forms.TextBox();
            this.labelANG = new System.Windows.Forms.Label();
            this.BONYSGEOG = new System.Windows.Forms.Button();
            this.textBoxGEOG = new System.Windows.Forms.TextBox();
            this.labelGEOG = new System.Windows.Forms.Label();
            this.BONYSRODLIT = new System.Windows.Forms.Button();
            this.textBoxRODLIT = new System.Windows.Forms.TextBox();
            this.labelRODLIT = new System.Windows.Forms.Label();
            this.BONYSGEOM = new System.Windows.Forms.Button();
            this.textBoxGEOM = new System.Windows.Forms.TextBox();
            this.labelGEOM = new System.Windows.Forms.Label();
            this.BONYSOBJ = new System.Windows.Forms.Button();
            this.textBoxOBJ = new System.Windows.Forms.TextBox();
            this.labelOBJ = new System.Windows.Forms.Label();
            this.BONYSMUS = new System.Windows.Forms.Button();
            this.textBoxMUS = new System.Windows.Forms.TextBox();
            this.labelMUS = new System.Windows.Forms.Label();
            this.BONYSLIT = new System.Windows.Forms.Button();
            this.textBoxLIT = new System.Windows.Forms.TextBox();
            this.labelLIT = new System.Windows.Forms.Label();
            this.BONYSHIS = new System.Windows.Forms.Button();
            this.textBoxHIS = new System.Windows.Forms.TextBox();
            this.labelHIS = new System.Windows.Forms.Label();
            this.BONYSINF = new System.Windows.Forms.Button();
            this.textBoxINF = new System.Windows.Forms.TextBox();
            this.labelINF = new System.Windows.Forms.Label();
            this.BONYSFIZRA = new System.Windows.Forms.Button();
            this.textBoxFIZRA = new System.Windows.Forms.TextBox();
            this.labelFIZRA = new System.Windows.Forms.Label();
            this.BONYSPHY = new System.Windows.Forms.Button();
            this.textBoxPHY = new System.Windows.Forms.TextBox();
            this.labelPHY = new System.Windows.Forms.Label();
            this.BONYSBIO = new System.Windows.Forms.Button();
            this.textBoxBIO = new System.Windows.Forms.TextBox();
            this.labelBIO = new System.Windows.Forms.Label();
            this.BONYSRUS = new System.Windows.Forms.Button();
            this.textBoxRUS = new System.Windows.Forms.TextBox();
            this.labelRUS = new System.Windows.Forms.Label();
            this.BONYSMATPRACT = new System.Windows.Forms.Button();
            this.textBoxMATPRACT = new System.Windows.Forms.TextBox();
            this.labelMATPRACT = new System.Windows.Forms.Label();
            this.BONYSIZO = new System.Windows.Forms.Button();
            this.textBoxIZO = new System.Windows.Forms.TextBox();
            this.labelIZO = new System.Windows.Forms.Label();
            this.BONYSRODYAZ = new System.Windows.Forms.Button();
            this.textBoxRODYAZ = new System.Windows.Forms.TextBox();
            this.labelRODYAZ = new System.Windows.Forms.Label();
            this.BONYSOBS = new System.Windows.Forms.Button();
            this.textBoxOBS = new System.Windows.Forms.TextBox();
            this.labelOBS = new System.Windows.Forms.Label();
            this.BONYSCHER = new System.Windows.Forms.Button();
            this.textBoxCHER = new System.Windows.Forms.TextBox();
            this.labelCHER = new System.Windows.Forms.Label();
            this.BONYSHIM = new System.Windows.Forms.Button();
            this.textBoxHIM = new System.Windows.Forms.TextBox();
            this.labelHIM = new System.Windows.Forms.Label();
            this.checkALL = new System.Windows.Forms.CheckBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonBONYSMIRA
            // 
            this.buttonBONYSMIRA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.buttonBONYSMIRA.Location = new System.Drawing.Point(268, 275);
            this.buttonBONYSMIRA.Name = "buttonBONYSMIRA";
            this.buttonBONYSMIRA.Size = new System.Drawing.Size(206, 23);
            this.buttonBONYSMIRA.TabIndex = 8;
            this.buttonBONYSMIRA.Text = "Общий бонус:";
            this.buttonBONYSMIRA.UseVisualStyleBackColor = false;
            this.buttonBONYSMIRA.Click += new System.EventHandler(this.buttonBONYSMIRA_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkALL);
            this.groupBox1.Controls.Add(this.checkRODYAZ);
            this.groupBox1.Controls.Add(this.checkBoxMATPRACT);
            this.groupBox1.Controls.Add(this.checkIZO);
            this.groupBox1.Controls.Add(this.checkMUS);
            this.groupBox1.Controls.Add(this.checkCHER);
            this.groupBox1.Controls.Add(this.checkHIM);
            this.groupBox1.Controls.Add(this.checkFIZRA);
            this.groupBox1.Controls.Add(this.checkPHY);
            this.groupBox1.Controls.Add(this.checkBIO);
            this.groupBox1.Controls.Add(this.checkRODLIT);
            this.groupBox1.Controls.Add(this.checkOBJ);
            this.groupBox1.Controls.Add(this.checkOBS);
            this.groupBox1.Controls.Add(this.checkLIT);
            this.groupBox1.Controls.Add(this.checkHIS);
            this.groupBox1.Controls.Add(this.checkINF);
            this.groupBox1.Controls.Add(this.checkGEOM);
            this.groupBox1.Controls.Add(this.checkGEOG);
            this.groupBox1.Controls.Add(this.checkRUS);
            this.groupBox1.Controls.Add(this.checkANG);
            this.groupBox1.Controls.Add(this.checkALG);
            this.groupBox1.Location = new System.Drawing.Point(12, 49);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(250, 270);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Предметы";
            // 
            // checkRODYAZ
            // 
            this.checkRODYAZ.AutoSize = true;
            this.checkRODYAZ.Location = new System.Drawing.Point(130, 196);
            this.checkRODYAZ.Name = "checkRODYAZ";
            this.checkRODYAZ.Size = new System.Drawing.Size(92, 17);
            this.checkRODYAZ.TabIndex = 19;
            this.checkRODYAZ.Text = "Родной язык";
            this.checkRODYAZ.UseVisualStyleBackColor = true;
            this.checkRODYAZ.CheckedChanged += new System.EventHandler(this.checkRODYAZ_CheckedChanged);
            // 
            // checkBoxMATPRACT
            // 
            this.checkBoxMATPRACT.AutoSize = true;
            this.checkBoxMATPRACT.Location = new System.Drawing.Point(130, 18);
            this.checkBoxMATPRACT.Name = "checkBoxMATPRACT";
            this.checkBoxMATPRACT.Size = new System.Drawing.Size(120, 17);
            this.checkBoxMATPRACT.TabIndex = 18;
            this.checkBoxMATPRACT.Text = "Матим. приктикум";
            this.checkBoxMATPRACT.CheckedChanged += new System.EventHandler(this.checkBoxMATPRACT_CheckedChanged);
            // 
            // checkIZO
            // 
            this.checkIZO.AutoSize = true;
            this.checkIZO.Location = new System.Drawing.Point(130, 219);
            this.checkIZO.Name = "checkIZO";
            this.checkIZO.Size = new System.Drawing.Size(49, 17);
            this.checkIZO.TabIndex = 17;
            this.checkIZO.Text = "ИЗО";
            this.checkIZO.UseVisualStyleBackColor = true;
            this.checkIZO.CheckedChanged += new System.EventHandler(this.checkIZO_CheckedChanged);
            // 
            // checkMUS
            // 
            this.checkMUS.AutoSize = true;
            this.checkMUS.Location = new System.Drawing.Point(5, 196);
            this.checkMUS.Name = "checkMUS";
            this.checkMUS.Size = new System.Drawing.Size(66, 17);
            this.checkMUS.TabIndex = 16;
            this.checkMUS.Text = "Музыка";
            this.checkMUS.UseVisualStyleBackColor = true;
            this.checkMUS.CheckedChanged += new System.EventHandler(this.checkMUS_CheckedChanged);
            // 
            // checkCHER
            // 
            this.checkCHER.AutoSize = true;
            this.checkCHER.Location = new System.Drawing.Point(130, 151);
            this.checkCHER.Name = "checkCHER";
            this.checkCHER.Size = new System.Drawing.Size(75, 17);
            this.checkCHER.TabIndex = 15;
            this.checkCHER.Text = "Черчение";
            this.checkCHER.UseVisualStyleBackColor = true;
            this.checkCHER.CheckedChanged += new System.EventHandler(this.checkCHER_CheckedChanged);
            // 
            // checkHIM
            // 
            this.checkHIM.AutoSize = true;
            this.checkHIM.Location = new System.Drawing.Point(130, 128);
            this.checkHIM.Name = "checkHIM";
            this.checkHIM.Size = new System.Drawing.Size(59, 17);
            this.checkHIM.TabIndex = 14;
            this.checkHIM.Text = "Химия";
            this.checkHIM.UseVisualStyleBackColor = true;
            this.checkHIM.CheckedChanged += new System.EventHandler(this.checkHIM_CheckedChanged);
            // 
            // checkFIZRA
            // 
            this.checkFIZRA.AutoSize = true;
            this.checkFIZRA.Location = new System.Drawing.Point(130, 105);
            this.checkFIZRA.Name = "checkFIZRA";
            this.checkFIZRA.Size = new System.Drawing.Size(64, 17);
            this.checkFIZRA.TabIndex = 13;
            this.checkFIZRA.Text = "Физ-ра";
            this.checkFIZRA.UseVisualStyleBackColor = true;
            this.checkFIZRA.CheckedChanged += new System.EventHandler(this.checkFIZRA_CheckedChanged);
            // 
            // checkPHY
            // 
            this.checkPHY.AutoSize = true;
            this.checkPHY.Location = new System.Drawing.Point(130, 82);
            this.checkPHY.Name = "checkPHY";
            this.checkPHY.Size = new System.Drawing.Size(67, 17);
            this.checkPHY.TabIndex = 12;
            this.checkPHY.Text = "Физика";
            this.checkPHY.UseVisualStyleBackColor = true;
            this.checkPHY.CheckedChanged += new System.EventHandler(this.checkPHY_CheckedChanged);
            // 
            // checkBIO
            // 
            this.checkBIO.AutoSize = true;
            this.checkBIO.Location = new System.Drawing.Point(130, 61);
            this.checkBIO.Name = "checkBIO";
            this.checkBIO.Size = new System.Drawing.Size(74, 17);
            this.checkBIO.TabIndex = 11;
            this.checkBIO.Text = "Биология";
            this.checkBIO.UseVisualStyleBackColor = true;
            this.checkBIO.CheckedChanged += new System.EventHandler(this.checkBIO_CheckedChanged);
            // 
            // checkRODLIT
            // 
            this.checkRODLIT.AutoSize = true;
            this.checkRODLIT.Location = new System.Drawing.Point(5, 61);
            this.checkRODLIT.Name = "checkRODLIT";
            this.checkRODLIT.Size = new System.Drawing.Size(123, 17);
            this.checkRODLIT.TabIndex = 10;
            this.checkRODLIT.Text = "Родная литература";
            this.checkRODLIT.UseVisualStyleBackColor = true;
            this.checkRODLIT.CheckedChanged += new System.EventHandler(this.checkRODLIT_CheckedChanged);
            // 
            // checkOBJ
            // 
            this.checkOBJ.AutoSize = true;
            this.checkOBJ.Location = new System.Drawing.Point(5, 219);
            this.checkOBJ.Name = "checkOBJ";
            this.checkOBJ.Size = new System.Drawing.Size(52, 17);
            this.checkOBJ.TabIndex = 9;
            this.checkOBJ.Text = "ОБЖ";
            this.checkOBJ.CheckedChanged += new System.EventHandler(this.checkOBJ_CheckedChanged);
            // 
            // checkOBS
            // 
            this.checkOBS.AutoSize = true;
            this.checkOBS.Location = new System.Drawing.Point(130, 174);
            this.checkOBS.Name = "checkOBS";
            this.checkOBS.Size = new System.Drawing.Size(114, 17);
            this.checkOBS.TabIndex = 8;
            this.checkOBS.Text = "Обществознание";
            this.checkOBS.UseVisualStyleBackColor = true;
            this.checkOBS.CheckedChanged += new System.EventHandler(this.checkOBS_CheckedChanged);
            // 
            // checkLIT
            // 
            this.checkLIT.AutoSize = true;
            this.checkLIT.Location = new System.Drawing.Point(5, 173);
            this.checkLIT.Name = "checkLIT";
            this.checkLIT.Size = new System.Drawing.Size(85, 17);
            this.checkLIT.TabIndex = 7;
            this.checkLIT.Text = "Литература";
            this.checkLIT.UseVisualStyleBackColor = true;
            this.checkLIT.CheckedChanged += new System.EventHandler(this.checkLIT_CheckedChanged);
            // 
            // checkHIS
            // 
            this.checkHIS.AutoSize = true;
            this.checkHIS.Location = new System.Drawing.Point(5, 151);
            this.checkHIS.Name = "checkHIS";
            this.checkHIS.Size = new System.Drawing.Size(69, 17);
            this.checkHIS.TabIndex = 6;
            this.checkHIS.Text = "История";
            this.checkHIS.UseVisualStyleBackColor = true;
            this.checkHIS.CheckedChanged += new System.EventHandler(this.checkHIS_CheckedChanged);
            // 
            // checkINF
            // 
            this.checkINF.AutoSize = true;
            this.checkINF.Location = new System.Drawing.Point(5, 128);
            this.checkINF.Name = "checkINF";
            this.checkINF.Size = new System.Drawing.Size(97, 17);
            this.checkINF.TabIndex = 5;
            this.checkINF.Text = "Информатика";
            this.checkINF.UseVisualStyleBackColor = true;
            this.checkINF.CheckedChanged += new System.EventHandler(this.checkINF_CheckedChanged);
            // 
            // checkGEOM
            // 
            this.checkGEOM.AutoSize = true;
            this.checkGEOM.Location = new System.Drawing.Point(5, 105);
            this.checkGEOM.Name = "checkGEOM";
            this.checkGEOM.Size = new System.Drawing.Size(81, 17);
            this.checkGEOM.TabIndex = 4;
            this.checkGEOM.Text = "Геометрия";
            this.checkGEOM.UseVisualStyleBackColor = true;
            this.checkGEOM.CheckedChanged += new System.EventHandler(this.checkGEOM_CheckedChanged);
            // 
            // checkGEOG
            // 
            this.checkGEOG.AutoSize = true;
            this.checkGEOG.Location = new System.Drawing.Point(5, 82);
            this.checkGEOG.Name = "checkGEOG";
            this.checkGEOG.Size = new System.Drawing.Size(81, 17);
            this.checkGEOG.TabIndex = 3;
            this.checkGEOG.Text = "География";
            this.checkGEOG.UseVisualStyleBackColor = true;
            this.checkGEOG.CheckedChanged += new System.EventHandler(this.checkGEOG_CheckedChanged);
            // 
            // checkRUS
            // 
            this.checkRUS.AutoSize = true;
            this.checkRUS.Location = new System.Drawing.Point(130, 40);
            this.checkRUS.Name = "checkRUS";
            this.checkRUS.Size = new System.Drawing.Size(97, 17);
            this.checkRUS.TabIndex = 2;
            this.checkRUS.Text = "Русский язык";
            this.checkRUS.UseVisualStyleBackColor = true;
            this.checkRUS.CheckedChanged += new System.EventHandler(this.checkRUS_CheckedChanged);
            // 
            // checkANG
            // 
            this.checkANG.AutoSize = true;
            this.checkANG.Location = new System.Drawing.Point(5, 40);
            this.checkANG.Name = "checkANG";
            this.checkANG.Size = new System.Drawing.Size(109, 17);
            this.checkANG.TabIndex = 1;
            this.checkANG.Text = "Английски язык";
            this.checkANG.UseVisualStyleBackColor = true;
            this.checkANG.CheckedChanged += new System.EventHandler(this.checkANG_CheckedChanged);
            // 
            // checkALG
            // 
            this.checkALG.AutoSize = true;
            this.checkALG.Location = new System.Drawing.Point(5, 17);
            this.checkALG.Name = "checkALG";
            this.checkALG.Size = new System.Drawing.Size(68, 17);
            this.checkALG.TabIndex = 0;
            this.checkALG.Text = "Алгебра";
            this.checkALG.UseVisualStyleBackColor = true;
            this.checkALG.CheckedChanged += new System.EventHandler(this.checkALG_CheckedChanged);
            // 
            // textBoxNAMEBABY
            // 
            this.textBoxNAMEBABY.Location = new System.Drawing.Point(12, 23);
            this.textBoxNAMEBABY.Name = "textBoxNAMEBABY";
            this.textBoxNAMEBABY.Size = new System.Drawing.Size(153, 20);
            this.textBoxNAMEBABY.TabIndex = 15;
            this.textBoxNAMEBABY.Tag = "";
            // 
            // labelNAMEBABY
            // 
            this.labelNAMEBABY.AutoSize = true;
            this.labelNAMEBABY.Location = new System.Drawing.Point(12, 7);
            this.labelNAMEBABY.Name = "labelNAMEBABY";
            this.labelNAMEBABY.Size = new System.Drawing.Size(198, 13);
            this.labelNAMEBABY.TabIndex = 16;
            this.labelNAMEBABY.Text = "Имя ребёнка(В родительном падеже)";
            // 
            // ALGEBRATEXT
            // 
            this.ALGEBRATEXT.AutoSize = true;
            this.ALGEBRATEXT.Location = new System.Drawing.Point(268, 49);
            this.ALGEBRATEXT.Name = "ALGEBRATEXT";
            this.ALGEBRATEXT.Size = new System.Drawing.Size(49, 13);
            this.ALGEBRATEXT.TabIndex = 17;
            this.ALGEBRATEXT.Text = "Алгебра";
            this.ALGEBRATEXT.Visible = false;
            // 
            // textBoxALG
            // 
            this.textBoxALG.Location = new System.Drawing.Point(268, 63);
            this.textBoxALG.Name = "textBoxALG";
            this.textBoxALG.Size = new System.Drawing.Size(62, 20);
            this.textBoxALG.TabIndex = 18;
            this.textBoxALG.Visible = false;
            // 
            // BONYSALG
            // 
            this.BONYSALG.BackColor = System.Drawing.Color.White;
            this.BONYSALG.Location = new System.Drawing.Point(336, 62);
            this.BONYSALG.Name = "BONYSALG";
            this.BONYSALG.Size = new System.Drawing.Size(107, 23);
            this.BONYSALG.TabIndex = 20;
            this.BONYSALG.Text = "Бонус равен: ";
            this.BONYSALG.UseVisualStyleBackColor = false;
            this.BONYSALG.Visible = false;
            this.BONYSALG.Click += new System.EventHandler(this.BONYSALG_Click);
            // 
            // BONYSANG
            // 
            this.BONYSANG.BackColor = System.Drawing.Color.Cyan;
            this.BONYSANG.Location = new System.Drawing.Point(336, 104);
            this.BONYSANG.Name = "BONYSANG";
            this.BONYSANG.Size = new System.Drawing.Size(107, 23);
            this.BONYSANG.TabIndex = 23;
            this.BONYSANG.Text = "Бонус равен: ";
            this.BONYSANG.UseVisualStyleBackColor = false;
            this.BONYSANG.Visible = false;
            this.BONYSANG.Click += new System.EventHandler(this.BONYSANG_Click_1);
            // 
            // textBoxANG
            // 
            this.textBoxANG.Location = new System.Drawing.Point(268, 105);
            this.textBoxANG.Name = "textBoxANG";
            this.textBoxANG.Size = new System.Drawing.Size(62, 20);
            this.textBoxANG.TabIndex = 22;
            this.textBoxANG.Visible = false;
            // 
            // labelANG
            // 
            this.labelANG.AutoSize = true;
            this.labelANG.Location = new System.Drawing.Point(268, 91);
            this.labelANG.Name = "labelANG";
            this.labelANG.Size = new System.Drawing.Size(96, 13);
            this.labelANG.TabIndex = 21;
            this.labelANG.Text = "Английский язык";
            this.labelANG.Visible = false;
            // 
            // BONYSGEOG
            // 
            this.BONYSGEOG.BackColor = System.Drawing.Color.Lime;
            this.BONYSGEOG.Location = new System.Drawing.Point(336, 192);
            this.BONYSGEOG.Name = "BONYSGEOG";
            this.BONYSGEOG.Size = new System.Drawing.Size(107, 23);
            this.BONYSGEOG.TabIndex = 29;
            this.BONYSGEOG.Text = "Бонус равен: ";
            this.BONYSGEOG.UseVisualStyleBackColor = false;
            this.BONYSGEOG.Visible = false;
            this.BONYSGEOG.Click += new System.EventHandler(this.BONYSGEOG_Click_1);
            // 
            // textBoxGEOG
            // 
            this.textBoxGEOG.Location = new System.Drawing.Point(268, 193);
            this.textBoxGEOG.Name = "textBoxGEOG";
            this.textBoxGEOG.Size = new System.Drawing.Size(62, 20);
            this.textBoxGEOG.TabIndex = 28;
            this.textBoxGEOG.Visible = false;
            // 
            // labelGEOG
            // 
            this.labelGEOG.AutoSize = true;
            this.labelGEOG.Location = new System.Drawing.Point(268, 179);
            this.labelGEOG.Name = "labelGEOG";
            this.labelGEOG.Size = new System.Drawing.Size(62, 13);
            this.labelGEOG.TabIndex = 27;
            this.labelGEOG.Text = "География";
            this.labelGEOG.Visible = false;
            // 
            // BONYSRODLIT
            // 
            this.BONYSRODLIT.BackColor = System.Drawing.Color.Red;
            this.BONYSRODLIT.Location = new System.Drawing.Point(336, 150);
            this.BONYSRODLIT.Name = "BONYSRODLIT";
            this.BONYSRODLIT.Size = new System.Drawing.Size(107, 23);
            this.BONYSRODLIT.TabIndex = 26;
            this.BONYSRODLIT.Text = "Бонус равен: ";
            this.BONYSRODLIT.UseVisualStyleBackColor = false;
            this.BONYSRODLIT.Visible = false;
            this.BONYSRODLIT.Click += new System.EventHandler(this.BONYSRODLIT_Click);
            // 
            // textBoxRODLIT
            // 
            this.textBoxRODLIT.Location = new System.Drawing.Point(268, 151);
            this.textBoxRODLIT.Name = "textBoxRODLIT";
            this.textBoxRODLIT.Size = new System.Drawing.Size(62, 20);
            this.textBoxRODLIT.TabIndex = 25;
            this.textBoxRODLIT.Visible = false;
            // 
            // labelRODLIT
            // 
            this.labelRODLIT.AutoSize = true;
            this.labelRODLIT.Location = new System.Drawing.Point(268, 137);
            this.labelRODLIT.Name = "labelRODLIT";
            this.labelRODLIT.Size = new System.Drawing.Size(104, 13);
            this.labelRODLIT.TabIndex = 24;
            this.labelRODLIT.Text = "Родная литература";
            this.labelRODLIT.Visible = false;
            // 
            // BONYSGEOM
            // 
            this.BONYSGEOM.BackColor = System.Drawing.Color.Teal;
            this.BONYSGEOM.Location = new System.Drawing.Point(336, 234);
            this.BONYSGEOM.Name = "BONYSGEOM";
            this.BONYSGEOM.Size = new System.Drawing.Size(107, 23);
            this.BONYSGEOM.TabIndex = 32;
            this.BONYSGEOM.Text = "Бонус равен: ";
            this.BONYSGEOM.UseVisualStyleBackColor = false;
            this.BONYSGEOM.Visible = false;
            this.BONYSGEOM.Click += new System.EventHandler(this.BONYSGEOM_Click_1);
            // 
            // textBoxGEOM
            // 
            this.textBoxGEOM.Location = new System.Drawing.Point(268, 236);
            this.textBoxGEOM.Name = "textBoxGEOM";
            this.textBoxGEOM.Size = new System.Drawing.Size(62, 20);
            this.textBoxGEOM.TabIndex = 31;
            this.textBoxGEOM.Visible = false;
            // 
            // labelGEOM
            // 
            this.labelGEOM.AutoSize = true;
            this.labelGEOM.Location = new System.Drawing.Point(268, 221);
            this.labelGEOM.Name = "labelGEOM";
            this.labelGEOM.Size = new System.Drawing.Size(62, 13);
            this.labelGEOM.TabIndex = 30;
            this.labelGEOM.Text = "Геометрия";
            this.labelGEOM.Visible = false;
            // 
            // BONYSOBJ
            // 
            this.BONYSOBJ.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.BONYSOBJ.Location = new System.Drawing.Point(519, 233);
            this.BONYSOBJ.Name = "BONYSOBJ";
            this.BONYSOBJ.Size = new System.Drawing.Size(107, 23);
            this.BONYSOBJ.TabIndex = 47;
            this.BONYSOBJ.Text = "Бонус равен: ";
            this.BONYSOBJ.UseVisualStyleBackColor = false;
            this.BONYSOBJ.Visible = false;
            this.BONYSOBJ.Click += new System.EventHandler(this.BONYSOBJ_Click);
            // 
            // textBoxOBJ
            // 
            this.textBoxOBJ.Location = new System.Drawing.Point(451, 235);
            this.textBoxOBJ.Name = "textBoxOBJ";
            this.textBoxOBJ.Size = new System.Drawing.Size(62, 20);
            this.textBoxOBJ.TabIndex = 46;
            this.textBoxOBJ.Visible = false;
            // 
            // labelOBJ
            // 
            this.labelOBJ.AutoSize = true;
            this.labelOBJ.Location = new System.Drawing.Point(451, 220);
            this.labelOBJ.Name = "labelOBJ";
            this.labelOBJ.Size = new System.Drawing.Size(33, 13);
            this.labelOBJ.TabIndex = 45;
            this.labelOBJ.Text = "ОБЖ";
            this.labelOBJ.Visible = false;
            // 
            // BONYSMUS
            // 
            this.BONYSMUS.BackColor = System.Drawing.Color.Gray;
            this.BONYSMUS.Location = new System.Drawing.Point(519, 191);
            this.BONYSMUS.Name = "BONYSMUS";
            this.BONYSMUS.Size = new System.Drawing.Size(107, 23);
            this.BONYSMUS.TabIndex = 44;
            this.BONYSMUS.Text = "Бонус равен: ";
            this.BONYSMUS.UseVisualStyleBackColor = false;
            this.BONYSMUS.Visible = false;
            this.BONYSMUS.Click += new System.EventHandler(this.BONYSMUS_Click);
            // 
            // textBoxMUS
            // 
            this.textBoxMUS.Location = new System.Drawing.Point(451, 192);
            this.textBoxMUS.Name = "textBoxMUS";
            this.textBoxMUS.Size = new System.Drawing.Size(62, 20);
            this.textBoxMUS.TabIndex = 43;
            this.textBoxMUS.Visible = false;
            // 
            // labelMUS
            // 
            this.labelMUS.AutoSize = true;
            this.labelMUS.Location = new System.Drawing.Point(451, 178);
            this.labelMUS.Name = "labelMUS";
            this.labelMUS.Size = new System.Drawing.Size(47, 13);
            this.labelMUS.TabIndex = 42;
            this.labelMUS.Text = "Музыка";
            this.labelMUS.Visible = false;
            // 
            // BONYSLIT
            // 
            this.BONYSLIT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.BONYSLIT.Location = new System.Drawing.Point(519, 149);
            this.BONYSLIT.Name = "BONYSLIT";
            this.BONYSLIT.Size = new System.Drawing.Size(107, 23);
            this.BONYSLIT.TabIndex = 41;
            this.BONYSLIT.Text = "Бонус равен: ";
            this.BONYSLIT.UseVisualStyleBackColor = false;
            this.BONYSLIT.Visible = false;
            this.BONYSLIT.Click += new System.EventHandler(this.BONYSLIT_Click);
            // 
            // textBoxLIT
            // 
            this.textBoxLIT.Location = new System.Drawing.Point(451, 150);
            this.textBoxLIT.Name = "textBoxLIT";
            this.textBoxLIT.Size = new System.Drawing.Size(62, 20);
            this.textBoxLIT.TabIndex = 40;
            this.textBoxLIT.Visible = false;
            // 
            // labelLIT
            // 
            this.labelLIT.AutoSize = true;
            this.labelLIT.Location = new System.Drawing.Point(451, 136);
            this.labelLIT.Name = "labelLIT";
            this.labelLIT.Size = new System.Drawing.Size(66, 13);
            this.labelLIT.TabIndex = 39;
            this.labelLIT.Text = "Литература";
            this.labelLIT.Visible = false;
            // 
            // BONYSHIS
            // 
            this.BONYSHIS.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.BONYSHIS.Location = new System.Drawing.Point(519, 103);
            this.BONYSHIS.Name = "BONYSHIS";
            this.BONYSHIS.Size = new System.Drawing.Size(107, 23);
            this.BONYSHIS.TabIndex = 38;
            this.BONYSHIS.Text = "Бонус равен: ";
            this.BONYSHIS.UseVisualStyleBackColor = false;
            this.BONYSHIS.Visible = false;
            this.BONYSHIS.Click += new System.EventHandler(this.BONYSHIS_Click);
            // 
            // textBoxHIS
            // 
            this.textBoxHIS.Location = new System.Drawing.Point(451, 104);
            this.textBoxHIS.Name = "textBoxHIS";
            this.textBoxHIS.Size = new System.Drawing.Size(62, 20);
            this.textBoxHIS.TabIndex = 37;
            this.textBoxHIS.Visible = false;
            // 
            // labelHIS
            // 
            this.labelHIS.AutoSize = true;
            this.labelHIS.Location = new System.Drawing.Point(451, 90);
            this.labelHIS.Name = "labelHIS";
            this.labelHIS.Size = new System.Drawing.Size(50, 13);
            this.labelHIS.TabIndex = 36;
            this.labelHIS.Text = "История";
            this.labelHIS.Visible = false;
            // 
            // BONYSINF
            // 
            this.BONYSINF.BackColor = System.Drawing.Color.Purple;
            this.BONYSINF.ForeColor = System.Drawing.Color.White;
            this.BONYSINF.Location = new System.Drawing.Point(519, 61);
            this.BONYSINF.Name = "BONYSINF";
            this.BONYSINF.Size = new System.Drawing.Size(107, 23);
            this.BONYSINF.TabIndex = 35;
            this.BONYSINF.Text = "Бонус равен: ";
            this.BONYSINF.UseVisualStyleBackColor = false;
            this.BONYSINF.Visible = false;
            this.BONYSINF.Click += new System.EventHandler(this.BONYSINF_Click);
            // 
            // textBoxINF
            // 
            this.textBoxINF.Location = new System.Drawing.Point(451, 62);
            this.textBoxINF.Name = "textBoxINF";
            this.textBoxINF.Size = new System.Drawing.Size(62, 20);
            this.textBoxINF.TabIndex = 34;
            this.textBoxINF.Visible = false;
            // 
            // labelINF
            // 
            this.labelINF.AutoSize = true;
            this.labelINF.Location = new System.Drawing.Point(451, 48);
            this.labelINF.Name = "labelINF";
            this.labelINF.Size = new System.Drawing.Size(78, 13);
            this.labelINF.TabIndex = 33;
            this.labelINF.Text = "Информатика";
            this.labelINF.Visible = false;
            // 
            // BONYSFIZRA
            // 
            this.BONYSFIZRA.BackColor = System.Drawing.Color.Navy;
            this.BONYSFIZRA.ForeColor = System.Drawing.Color.White;
            this.BONYSFIZRA.Location = new System.Drawing.Point(701, 235);
            this.BONYSFIZRA.Name = "BONYSFIZRA";
            this.BONYSFIZRA.Size = new System.Drawing.Size(107, 23);
            this.BONYSFIZRA.TabIndex = 62;
            this.BONYSFIZRA.Text = "Бонус равен: ";
            this.BONYSFIZRA.UseVisualStyleBackColor = false;
            this.BONYSFIZRA.Visible = false;
            this.BONYSFIZRA.Click += new System.EventHandler(this.BONYSFIZRA_Click);
            // 
            // textBoxFIZRA
            // 
            this.textBoxFIZRA.Location = new System.Drawing.Point(633, 236);
            this.textBoxFIZRA.Name = "textBoxFIZRA";
            this.textBoxFIZRA.Size = new System.Drawing.Size(62, 20);
            this.textBoxFIZRA.TabIndex = 61;
            this.textBoxFIZRA.Visible = false;
            // 
            // labelFIZRA
            // 
            this.labelFIZRA.AutoSize = true;
            this.labelFIZRA.Location = new System.Drawing.Point(633, 221);
            this.labelFIZRA.Name = "labelFIZRA";
            this.labelFIZRA.Size = new System.Drawing.Size(45, 13);
            this.labelFIZRA.TabIndex = 60;
            this.labelFIZRA.Text = "Физ-ра";
            this.labelFIZRA.Visible = false;
            // 
            // BONYSPHY
            // 
            this.BONYSPHY.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.BONYSPHY.ForeColor = System.Drawing.Color.White;
            this.BONYSPHY.Location = new System.Drawing.Point(701, 192);
            this.BONYSPHY.Name = "BONYSPHY";
            this.BONYSPHY.Size = new System.Drawing.Size(107, 23);
            this.BONYSPHY.TabIndex = 59;
            this.BONYSPHY.Text = "Бонус равен: ";
            this.BONYSPHY.UseVisualStyleBackColor = false;
            this.BONYSPHY.Visible = false;
            this.BONYSPHY.Click += new System.EventHandler(this.BONYSPHY_Click);
            // 
            // textBoxPHY
            // 
            this.textBoxPHY.Location = new System.Drawing.Point(633, 193);
            this.textBoxPHY.Name = "textBoxPHY";
            this.textBoxPHY.Size = new System.Drawing.Size(62, 20);
            this.textBoxPHY.TabIndex = 58;
            this.textBoxPHY.Visible = false;
            // 
            // labelPHY
            // 
            this.labelPHY.AutoSize = true;
            this.labelPHY.Location = new System.Drawing.Point(633, 179);
            this.labelPHY.Name = "labelPHY";
            this.labelPHY.Size = new System.Drawing.Size(48, 13);
            this.labelPHY.TabIndex = 57;
            this.labelPHY.Text = "Физика";
            this.labelPHY.Visible = false;
            // 
            // BONYSBIO
            // 
            this.BONYSBIO.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.BONYSBIO.Location = new System.Drawing.Point(701, 150);
            this.BONYSBIO.Name = "BONYSBIO";
            this.BONYSBIO.Size = new System.Drawing.Size(107, 23);
            this.BONYSBIO.TabIndex = 56;
            this.BONYSBIO.Text = "Бонус равен: ";
            this.BONYSBIO.UseVisualStyleBackColor = false;
            this.BONYSBIO.Visible = false;
            this.BONYSBIO.Click += new System.EventHandler(this.BONYSBIO_Click);
            // 
            // textBoxBIO
            // 
            this.textBoxBIO.Location = new System.Drawing.Point(633, 151);
            this.textBoxBIO.Name = "textBoxBIO";
            this.textBoxBIO.Size = new System.Drawing.Size(62, 20);
            this.textBoxBIO.TabIndex = 55;
            this.textBoxBIO.Visible = false;
            // 
            // labelBIO
            // 
            this.labelBIO.AutoSize = true;
            this.labelBIO.Location = new System.Drawing.Point(633, 137);
            this.labelBIO.Name = "labelBIO";
            this.labelBIO.Size = new System.Drawing.Size(55, 13);
            this.labelBIO.TabIndex = 54;
            this.labelBIO.Text = "Биология";
            this.labelBIO.Visible = false;
            // 
            // BONYSRUS
            // 
            this.BONYSRUS.BackColor = System.Drawing.Color.Maroon;
            this.BONYSRUS.ForeColor = System.Drawing.Color.White;
            this.BONYSRUS.Location = new System.Drawing.Point(701, 104);
            this.BONYSRUS.Name = "BONYSRUS";
            this.BONYSRUS.Size = new System.Drawing.Size(107, 23);
            this.BONYSRUS.TabIndex = 53;
            this.BONYSRUS.Text = "Бонус равен: ";
            this.BONYSRUS.UseVisualStyleBackColor = false;
            this.BONYSRUS.Visible = false;
            this.BONYSRUS.Click += new System.EventHandler(this.BONYSRUS_Click);
            // 
            // textBoxRUS
            // 
            this.textBoxRUS.Location = new System.Drawing.Point(633, 105);
            this.textBoxRUS.Name = "textBoxRUS";
            this.textBoxRUS.Size = new System.Drawing.Size(62, 20);
            this.textBoxRUS.TabIndex = 52;
            this.textBoxRUS.Visible = false;
            // 
            // labelRUS
            // 
            this.labelRUS.AutoSize = true;
            this.labelRUS.Location = new System.Drawing.Point(633, 91);
            this.labelRUS.Name = "labelRUS";
            this.labelRUS.Size = new System.Drawing.Size(78, 13);
            this.labelRUS.TabIndex = 51;
            this.labelRUS.Text = "Русский язык";
            this.labelRUS.Visible = false;
            // 
            // BONYSMATPRACT
            // 
            this.BONYSMATPRACT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.BONYSMATPRACT.Location = new System.Drawing.Point(701, 62);
            this.BONYSMATPRACT.Name = "BONYSMATPRACT";
            this.BONYSMATPRACT.Size = new System.Drawing.Size(107, 23);
            this.BONYSMATPRACT.TabIndex = 50;
            this.BONYSMATPRACT.Text = "Бонус равен: ";
            this.BONYSMATPRACT.UseVisualStyleBackColor = false;
            this.BONYSMATPRACT.Visible = false;
            this.BONYSMATPRACT.Click += new System.EventHandler(this.BONYSMATPRACT_Click);
            // 
            // textBoxMATPRACT
            // 
            this.textBoxMATPRACT.Location = new System.Drawing.Point(633, 63);
            this.textBoxMATPRACT.Name = "textBoxMATPRACT";
            this.textBoxMATPRACT.Size = new System.Drawing.Size(62, 20);
            this.textBoxMATPRACT.TabIndex = 49;
            this.textBoxMATPRACT.Visible = false;
            // 
            // labelMATPRACT
            // 
            this.labelMATPRACT.AutoSize = true;
            this.labelMATPRACT.Location = new System.Drawing.Point(633, 49);
            this.labelMATPRACT.Name = "labelMATPRACT";
            this.labelMATPRACT.Size = new System.Drawing.Size(101, 13);
            this.labelMATPRACT.TabIndex = 48;
            this.labelMATPRACT.Text = "Матим. практикум";
            this.labelMATPRACT.Visible = false;
            // 
            // BONYSIZO
            // 
            this.BONYSIZO.BackColor = System.Drawing.Color.Fuchsia;
            this.BONYSIZO.Location = new System.Drawing.Point(882, 233);
            this.BONYSIZO.Name = "BONYSIZO";
            this.BONYSIZO.Size = new System.Drawing.Size(107, 23);
            this.BONYSIZO.TabIndex = 77;
            this.BONYSIZO.Text = "Бонус равен: ";
            this.BONYSIZO.UseVisualStyleBackColor = false;
            this.BONYSIZO.Visible = false;
            this.BONYSIZO.Click += new System.EventHandler(this.BONYSIZO_Click);
            // 
            // textBoxIZO
            // 
            this.textBoxIZO.Location = new System.Drawing.Point(814, 235);
            this.textBoxIZO.Name = "textBoxIZO";
            this.textBoxIZO.Size = new System.Drawing.Size(62, 20);
            this.textBoxIZO.TabIndex = 76;
            this.textBoxIZO.Visible = false;
            // 
            // labelIZO
            // 
            this.labelIZO.AutoSize = true;
            this.labelIZO.Location = new System.Drawing.Point(814, 220);
            this.labelIZO.Name = "labelIZO";
            this.labelIZO.Size = new System.Drawing.Size(30, 13);
            this.labelIZO.TabIndex = 75;
            this.labelIZO.Text = "ИЗО";
            this.labelIZO.Visible = false;
            // 
            // BONYSRODYAZ
            // 
            this.BONYSRODYAZ.BackColor = System.Drawing.Color.Green;
            this.BONYSRODYAZ.Location = new System.Drawing.Point(882, 191);
            this.BONYSRODYAZ.Name = "BONYSRODYAZ";
            this.BONYSRODYAZ.Size = new System.Drawing.Size(107, 23);
            this.BONYSRODYAZ.TabIndex = 74;
            this.BONYSRODYAZ.Text = "Бонус равен: ";
            this.BONYSRODYAZ.UseVisualStyleBackColor = false;
            this.BONYSRODYAZ.Visible = false;
            this.BONYSRODYAZ.Click += new System.EventHandler(this.BONYSRODYAZ_Click);
            // 
            // textBoxRODYAZ
            // 
            this.textBoxRODYAZ.Location = new System.Drawing.Point(814, 192);
            this.textBoxRODYAZ.Name = "textBoxRODYAZ";
            this.textBoxRODYAZ.Size = new System.Drawing.Size(62, 20);
            this.textBoxRODYAZ.TabIndex = 73;
            this.textBoxRODYAZ.Visible = false;
            // 
            // labelRODYAZ
            // 
            this.labelRODYAZ.AutoSize = true;
            this.labelRODYAZ.Location = new System.Drawing.Point(814, 178);
            this.labelRODYAZ.Name = "labelRODYAZ";
            this.labelRODYAZ.Size = new System.Drawing.Size(73, 13);
            this.labelRODYAZ.TabIndex = 72;
            this.labelRODYAZ.Text = "Родной язык";
            this.labelRODYAZ.Visible = false;
            // 
            // BONYSOBS
            // 
            this.BONYSOBS.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.BONYSOBS.ForeColor = System.Drawing.Color.White;
            this.BONYSOBS.Location = new System.Drawing.Point(882, 149);
            this.BONYSOBS.Name = "BONYSOBS";
            this.BONYSOBS.Size = new System.Drawing.Size(107, 23);
            this.BONYSOBS.TabIndex = 71;
            this.BONYSOBS.Text = "Бонус равен: ";
            this.BONYSOBS.UseVisualStyleBackColor = false;
            this.BONYSOBS.Visible = false;
            this.BONYSOBS.Click += new System.EventHandler(this.BONYSOBS_Click);
            // 
            // textBoxOBS
            // 
            this.textBoxOBS.Location = new System.Drawing.Point(814, 150);
            this.textBoxOBS.Name = "textBoxOBS";
            this.textBoxOBS.Size = new System.Drawing.Size(62, 20);
            this.textBoxOBS.TabIndex = 70;
            this.textBoxOBS.Visible = false;
            // 
            // labelOBS
            // 
            this.labelOBS.AutoSize = true;
            this.labelOBS.Location = new System.Drawing.Point(814, 136);
            this.labelOBS.Name = "labelOBS";
            this.labelOBS.Size = new System.Drawing.Size(95, 13);
            this.labelOBS.TabIndex = 69;
            this.labelOBS.Text = "Обществознание";
            this.labelOBS.Visible = false;
            // 
            // BONYSCHER
            // 
            this.BONYSCHER.BackColor = System.Drawing.Color.Yellow;
            this.BONYSCHER.Location = new System.Drawing.Point(882, 103);
            this.BONYSCHER.Name = "BONYSCHER";
            this.BONYSCHER.Size = new System.Drawing.Size(107, 23);
            this.BONYSCHER.TabIndex = 68;
            this.BONYSCHER.Text = "Бонус равен: ";
            this.BONYSCHER.UseVisualStyleBackColor = false;
            this.BONYSCHER.Visible = false;
            this.BONYSCHER.Click += new System.EventHandler(this.BONYSCHER_Click);
            // 
            // textBoxCHER
            // 
            this.textBoxCHER.Location = new System.Drawing.Point(814, 104);
            this.textBoxCHER.Name = "textBoxCHER";
            this.textBoxCHER.Size = new System.Drawing.Size(62, 20);
            this.textBoxCHER.TabIndex = 67;
            this.textBoxCHER.Visible = false;
            // 
            // labelCHER
            // 
            this.labelCHER.AutoSize = true;
            this.labelCHER.Location = new System.Drawing.Point(814, 90);
            this.labelCHER.Name = "labelCHER";
            this.labelCHER.Size = new System.Drawing.Size(56, 13);
            this.labelCHER.TabIndex = 66;
            this.labelCHER.Text = "Черчение";
            this.labelCHER.Visible = false;
            // 
            // BONYSHIM
            // 
            this.BONYSHIM.BackColor = System.Drawing.Color.Black;
            this.BONYSHIM.ForeColor = System.Drawing.Color.White;
            this.BONYSHIM.Location = new System.Drawing.Point(882, 61);
            this.BONYSHIM.Name = "BONYSHIM";
            this.BONYSHIM.Size = new System.Drawing.Size(107, 23);
            this.BONYSHIM.TabIndex = 65;
            this.BONYSHIM.Text = "Бонус равен: ";
            this.BONYSHIM.UseVisualStyleBackColor = false;
            this.BONYSHIM.Visible = false;
            this.BONYSHIM.Click += new System.EventHandler(this.BONYSHIM_Click);
            // 
            // textBoxHIM
            // 
            this.textBoxHIM.Location = new System.Drawing.Point(814, 62);
            this.textBoxHIM.Name = "textBoxHIM";
            this.textBoxHIM.Size = new System.Drawing.Size(62, 20);
            this.textBoxHIM.TabIndex = 64;
            this.textBoxHIM.Visible = false;
            // 
            // labelHIM
            // 
            this.labelHIM.AutoSize = true;
            this.labelHIM.Location = new System.Drawing.Point(814, 48);
            this.labelHIM.Name = "labelHIM";
            this.labelHIM.Size = new System.Drawing.Size(40, 13);
            this.labelHIM.TabIndex = 63;
            this.labelHIM.Text = "Химия";
            this.labelHIM.Visible = false;
            // 
            // checkALL
            // 
            this.checkALL.AutoSize = true;
            this.checkALL.Location = new System.Drawing.Point(67, 242);
            this.checkALL.Name = "checkALL";
            this.checkALL.Size = new System.Drawing.Size(96, 17);
            this.checkALL.TabIndex = 20;
            this.checkALL.Text = "Включить всё";
            this.checkALL.UseVisualStyleBackColor = true;
            this.checkALL.CheckedChanged += new System.EventHandler(this.checkALL_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1062, 450);
            this.Controls.Add(this.BONYSIZO);
            this.Controls.Add(this.textBoxIZO);
            this.Controls.Add(this.labelIZO);
            this.Controls.Add(this.BONYSRODYAZ);
            this.Controls.Add(this.textBoxRODYAZ);
            this.Controls.Add(this.labelRODYAZ);
            this.Controls.Add(this.BONYSOBS);
            this.Controls.Add(this.textBoxOBS);
            this.Controls.Add(this.labelOBS);
            this.Controls.Add(this.BONYSCHER);
            this.Controls.Add(this.textBoxCHER);
            this.Controls.Add(this.labelCHER);
            this.Controls.Add(this.BONYSHIM);
            this.Controls.Add(this.textBoxHIM);
            this.Controls.Add(this.labelHIM);
            this.Controls.Add(this.BONYSFIZRA);
            this.Controls.Add(this.textBoxFIZRA);
            this.Controls.Add(this.labelFIZRA);
            this.Controls.Add(this.BONYSPHY);
            this.Controls.Add(this.textBoxPHY);
            this.Controls.Add(this.labelPHY);
            this.Controls.Add(this.BONYSBIO);
            this.Controls.Add(this.textBoxBIO);
            this.Controls.Add(this.labelBIO);
            this.Controls.Add(this.BONYSRUS);
            this.Controls.Add(this.textBoxRUS);
            this.Controls.Add(this.labelRUS);
            this.Controls.Add(this.BONYSMATPRACT);
            this.Controls.Add(this.textBoxMATPRACT);
            this.Controls.Add(this.labelMATPRACT);
            this.Controls.Add(this.BONYSOBJ);
            this.Controls.Add(this.textBoxOBJ);
            this.Controls.Add(this.labelOBJ);
            this.Controls.Add(this.BONYSMUS);
            this.Controls.Add(this.textBoxMUS);
            this.Controls.Add(this.labelMUS);
            this.Controls.Add(this.BONYSLIT);
            this.Controls.Add(this.textBoxLIT);
            this.Controls.Add(this.labelLIT);
            this.Controls.Add(this.BONYSHIS);
            this.Controls.Add(this.textBoxHIS);
            this.Controls.Add(this.labelHIS);
            this.Controls.Add(this.BONYSINF);
            this.Controls.Add(this.textBoxINF);
            this.Controls.Add(this.labelINF);
            this.Controls.Add(this.BONYSGEOM);
            this.Controls.Add(this.textBoxGEOM);
            this.Controls.Add(this.labelGEOM);
            this.Controls.Add(this.BONYSGEOG);
            this.Controls.Add(this.textBoxGEOG);
            this.Controls.Add(this.labelGEOG);
            this.Controls.Add(this.BONYSRODLIT);
            this.Controls.Add(this.textBoxRODLIT);
            this.Controls.Add(this.labelRODLIT);
            this.Controls.Add(this.BONYSANG);
            this.Controls.Add(this.textBoxANG);
            this.Controls.Add(this.labelANG);
            this.Controls.Add(this.BONYSALG);
            this.Controls.Add(this.textBoxALG);
            this.Controls.Add(this.ALGEBRATEXT);
            this.Controls.Add(this.labelNAMEBABY);
            this.Controls.Add(this.textBoxNAMEBABY);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.buttonBONYSMIRA);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button buttonBONYSMIRA;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox checkALG;
        private System.Windows.Forms.TextBox textBoxNAMEBABY;
        private System.Windows.Forms.Label labelNAMEBABY;
        private System.Windows.Forms.CheckBox checkRUS;
        private System.Windows.Forms.CheckBox checkANG;
        private System.Windows.Forms.CheckBox checkINF;
        private System.Windows.Forms.CheckBox checkGEOM;
        private System.Windows.Forms.CheckBox checkGEOG;
        private System.Windows.Forms.CheckBox checkRODLIT;
        private System.Windows.Forms.CheckBox checkOBJ;
        private System.Windows.Forms.CheckBox checkOBS;
        private System.Windows.Forms.CheckBox checkLIT;
        private System.Windows.Forms.CheckBox checkHIS;
        private System.Windows.Forms.CheckBox checkFIZRA;
        private System.Windows.Forms.CheckBox checkPHY;
        private System.Windows.Forms.CheckBox checkBIO;
        private System.Windows.Forms.CheckBox checkIZO;
        private System.Windows.Forms.CheckBox checkMUS;
        private System.Windows.Forms.CheckBox checkCHER;
        private System.Windows.Forms.CheckBox checkHIM;
        private System.Windows.Forms.Label ALGEBRATEXT;
        private System.Windows.Forms.TextBox textBoxALG;
        private System.Windows.Forms.Button BONYSALG;
        private System.Windows.Forms.Button BONYSANG;
        private System.Windows.Forms.TextBox textBoxANG;
        private System.Windows.Forms.Label labelANG;
        private System.Windows.Forms.Button BONYSGEOG;
        private System.Windows.Forms.TextBox textBoxGEOG;
        private System.Windows.Forms.Label labelGEOG;
        private System.Windows.Forms.Button BONYSRODLIT;
        private System.Windows.Forms.TextBox textBoxRODLIT;
        private System.Windows.Forms.Label labelRODLIT;
        private System.Windows.Forms.Button BONYSGEOM;
        private System.Windows.Forms.TextBox textBoxGEOM;
        private System.Windows.Forms.Label labelGEOM;
        private System.Windows.Forms.Button BONYSOBJ;
        private System.Windows.Forms.TextBox textBoxOBJ;
        private System.Windows.Forms.Label labelOBJ;
        private System.Windows.Forms.Button BONYSMUS;
        private System.Windows.Forms.TextBox textBoxMUS;
        private System.Windows.Forms.Label labelMUS;
        private System.Windows.Forms.Button BONYSLIT;
        private System.Windows.Forms.TextBox textBoxLIT;
        private System.Windows.Forms.Label labelLIT;
        private System.Windows.Forms.Button BONYSHIS;
        private System.Windows.Forms.TextBox textBoxHIS;
        private System.Windows.Forms.Label labelHIS;
        private System.Windows.Forms.Button BONYSINF;
        private System.Windows.Forms.TextBox textBoxINF;
        private System.Windows.Forms.Label labelINF;
        private System.Windows.Forms.CheckBox checkRODYAZ;
        private System.Windows.Forms.CheckBox checkBoxMATPRACT;
        private System.Windows.Forms.Button BONYSFIZRA;
        private System.Windows.Forms.TextBox textBoxFIZRA;
        private System.Windows.Forms.Label labelFIZRA;
        private System.Windows.Forms.Button BONYSPHY;
        private System.Windows.Forms.TextBox textBoxPHY;
        private System.Windows.Forms.Label labelPHY;
        private System.Windows.Forms.Button BONYSBIO;
        private System.Windows.Forms.TextBox textBoxBIO;
        private System.Windows.Forms.Label labelBIO;
        private System.Windows.Forms.Button BONYSRUS;
        private System.Windows.Forms.TextBox textBoxRUS;
        private System.Windows.Forms.Label labelRUS;
        private System.Windows.Forms.Button BONYSMATPRACT;
        private System.Windows.Forms.TextBox textBoxMATPRACT;
        private System.Windows.Forms.Label labelMATPRACT;
        private System.Windows.Forms.Button BONYSIZO;
        private System.Windows.Forms.TextBox textBoxIZO;
        private System.Windows.Forms.Label labelIZO;
        private System.Windows.Forms.Button BONYSRODYAZ;
        private System.Windows.Forms.TextBox textBoxRODYAZ;
        private System.Windows.Forms.Label labelRODYAZ;
        private System.Windows.Forms.Button BONYSOBS;
        private System.Windows.Forms.TextBox textBoxOBS;
        private System.Windows.Forms.Label labelOBS;
        private System.Windows.Forms.Button BONYSCHER;
        private System.Windows.Forms.TextBox textBoxCHER;
        private System.Windows.Forms.Label labelCHER;
        private System.Windows.Forms.Button BONYSHIM;
        private System.Windows.Forms.TextBox textBoxHIM;
        private System.Windows.Forms.Label labelHIM;
        private System.Windows.Forms.CheckBox checkALL;
    }
}

